import java.util.ArrayList;

class Vertice {
    ArrayList<Integer> adjacentes;

    Vertice() {
        adjacentes = new ArrayList<Integer>();
    }
}
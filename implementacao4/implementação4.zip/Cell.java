
public class Cell {
    
    int oferta;//linha
    int demanda;//coluna
    int theta;
    public Cell(int oferta, int demanda) {
        this.oferta=oferta;
        this.demanda=demanda;
    }
}
